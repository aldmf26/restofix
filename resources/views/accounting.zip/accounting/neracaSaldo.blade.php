@extends('accounting.template.master')
@section('content')
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                   
                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->

        <!-- Main content -->
        <div class="content">
            <div class="container">
                <div class="row">
                    <div class="col-lg-10">
                        <div class="card">
                            <div class="card-header">
                                <div class="row">
                                    <div class="col-lg-6">
                                        <h3>Neraca Saldo</h3>
                                    </div>
                                    <div class="col-lg-6">
                                        <a href="" class="btn btn-sm btn-info float-right">Save Neraca Saldo</a>
                                    </div>
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="form-group">
                                    <label for="">Tanggal</label>
                                    <input type="date" class="form-control col-lg-3">
                                    <table class="table mt-2">
                                        <tr class="table-info">
                                            <th width="50%">Akun</th>
                                            <th width="25%">Debit</th>
                                            <th width="30%">Kredit</th>
                                        </tr>
                                        <tr>
                                            <td>Kas</td>
                                            <td><input type="number" value="0" min="0" class="form-control"></td>
                                            <td><input type="number" value="0" min="0" class="form-control"></td>
                                        </tr>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <!-- /.content -->
    </div>
    <style>
        .modal-lg-max {
            max-width: 1000px;
        }

    </style>
    {{-- add akun --}}


    


    

  {{-- end export pertanggal --}}
    <!-- Control Sidebar -->
    <aside class="control-sidebar control-sidebar-dark">
        <!-- Control sidebar content goes here -->
    </aside>
    <!-- /.control-sidebar -->
@endsection
@section('script')
    
@endsection