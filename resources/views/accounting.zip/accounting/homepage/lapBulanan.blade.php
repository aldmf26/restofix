@extends('accounting.template.master')
@section('content')
    <div class="content-wrapper">
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                   
                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>

        <div class="content ml-2 mr-2">
         
                <div class="row justify-content-center">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="float-left">Laporan Bulanan </h3>  
                            </div>
                            <div class="card-body">
                                                         
                            </div>
                        </div>
                    </div>
                </div>
          
        </div>
    </div>
@endsection