<div class="row">
    <div class="col-lg-12">
        <table class="table data-table table-striopped" id="tb_post">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Post center</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>1</td>
                    <td>1</td>
                    <td></td>
                </tr>
            </tbody>
        </table>
    </div>
</div>